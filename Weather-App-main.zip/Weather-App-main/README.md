![Black Minimal Motivation Quote LinkedIn Banner (2)](https://user-images.githubusercontent.com/90236635/232291203-4d6bed99-30e5-4837-96b6-98bbbef053d3.png)

## About
 - This is a simple weather website.
 -  Pure HTML, CSS, JavaScript used.